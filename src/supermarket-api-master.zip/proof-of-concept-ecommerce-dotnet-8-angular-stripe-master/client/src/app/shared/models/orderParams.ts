export class OrderParams {
    pageNumber = 1;
    pageSize = 10;
    filter = '';
}