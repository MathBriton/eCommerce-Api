export const environment = {
  production: true,
  apiUrl: 'api/',
  hubUrl: 'hub/notifications',
  stripePublicKey:
    'pk_test_51QblihIkTuFXoxEtSfAgwLARGvz3vt6lLucDPhRZHtoV3s4L3c7Pkb13EhXCAriLoUQrhP1csy8BL85T0FFpKmFf008NBFeEhG',
};
